"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import Link from "next/link";

interface Message {
    _id: string;
    content: string;
    createdAt: string;
    type: "message" | "reply";
}

export default function ConversationPage() {
    const { conversationId } = useParams();
    const [messages, setMessages] = useState<Message[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchConversation = async () => {
            try {
                const token = localStorage.getItem(`senderToken_${conversationId}`);
                if (!token) {
                    setError("You do not have permission to view this conversation or the link is invalid.");
                    setLoading(false);
                    return;
                }

                const res = await fetch(`/api/conversation/${conversationId}?token=${token}`);
                const data = await res.json();

                if (!data.success) {
                    setError(data.message);
                    return;
                }

                setMessages(data.messages);
            } catch (err) {
                setError("Failed to load conversation");
            } finally {
                setLoading(false);
            }
        };

        if (conversationId) {
            fetchConversation();
        }
        
        
    }, [conversationId]);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-white text-black">
                <Loader2 className="animate-spin" size={32} />
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-white text-black px-6">
                <div className="w-full max-w-md text-center border border-neutral-200 rounded-2xl p-8 shadow-sm">
                    <h2 className="text-2xl font-black mb-4">Access Denied</h2>
                    <p className="text-neutral-500 mb-8">{error}</p>
                    <Link
                        href="/"
                        className="bg-black text-white px-8 py-3 rounded-lg text-sm font-bold transition hover:bg-neutral-800 hover:shadow-lg active:scale-95 inline-block"
                    >
                        Go to Homepage
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <main className="min-h-screen bg-white text-black py-16 px-6 font-sans">
            <div className="max-w-2xl mx-auto">
                <div className="text-center mb-12">
                    <h1 className="text-3xl font-black tracking-tight">Anonymous Conversation</h1>
                    <p className="text-neutral-500 mt-2 text-sm">
                        Keep this link safe to check for new replies. Only you can access this.
                    </p>
                </div>

                <div className="space-y-6">
                    {messages.map((msg, index) => {
                        const isReply = msg.type === "reply";
                        return (
                            <div
                                key={msg._id}
                                className={`flex flex-col ${isReply ? "items-start" : "items-end"}`}
                            >
                                <div
                                    className={`max-w-[80%] p-5 rounded-2xl border ${isReply
                                            ? "bg-black border-black text-white rounded-sm"
                                            : "bg-black border-black text-white rounded-sm"
                                        } shadow-sm`}
                                >
                                    <p className="text-xs font-bold uppercase tracking-wider mb-2 opacity-50">
                                        {isReply ? "Reply from User" : "You Asked"}
                                    </p>
                                    <p className="text-sm leading-relaxed">{msg.content}</p>
                                </div>
                                <span className="text-xs text-neutral-400 mt-2 font-medium px-1">
                                    {new Date(msg.createdAt).toLocaleString(undefined, {
                                        dateStyle: "medium",
                                        timeStyle: "short",
                                    })}
                                </span>
                            </div>
                        );
                    })}
                </div>

                {messages.length === 1 && (
                    <div className="mt-12 text-center p-8 border border-neutral-100 rounded-2xl bg-neutral-50">
                        <p className="text-neutral-500 text-sm font-medium">
                            Waiting for the user to reply...
                        </p>
                        <p className="text-xs text-neutral-400 mt-2">
                            Refresh this page later to check for updates.
                        </p>
                    </div>
                )}
            </div>
        </main>
    );
}
